<?php
/*
Plugin Name: Donors Widget
Description: Adds a sidebar widget to show the donors in a tag cloud
Author: Dsyko
Version: 1.0
Author URI: https://github.com/Dsyko
*/

// Put functions into one big function we'll call at the plugins_loaded
// action. This ensures that all required plugin functions are defined.
function widget_donors_init() {

	// Check for the required plugin functions. This will prevent fatal
	// errors occurring when you deactivate the dynamic-sidebar plugin.
	if ( !function_exists('register_sidebar_widget') )
		return;

	// This is the function that outputs our twitter widget
	function widget_donors($args) {
		
		// $args is an array of strings that help widgets to conform to
		// the active theme: before_widget, before_title, after_widget,
		// and after_title are the array keys. Default tags: li and h2.
		extract($args);

		// Each widget can store its own options. We keep strings here.
		$options = get_option('widget_donors');
		$donors = $options['donors'];
		$title = $options['title'];

		// These lines generate our output. Widgets can be very complex
		// but as you can see here, they can also be very, very simple.
		//echo $before_widget . $before_title . $title . $after_title;
		//echo 'Derp! ' . $username; 
		echo $before_widget
		?>
			<span id="ThnxDonators"><strong><?php echo $title;?></strong></span><br />
			<canvas width="210" height="210" id="donatorCanvas">
			  <ul>
				<?php foreach ($donors as $donor): ?>
					<li><a href="<?php echo $donor['url'] ?>" target="_blank" data-weight="<?php echo $donor['weight'] ?>" ammount="1btc"><?php echo $donor['name'] ?> </a></li>
				<?php endforeach; ?>
			  </ul>
			</canvas>
			
			<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
				<input type="hidden" name="cmd" value="_s-xclick"/>
				<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIHVwYJKoZIhvcNAQcEoIIHSDCCB0QCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYBAUh3UrF+0eYIkjnrIShfGohWXKbzIRhPVtRAof6nSQUs3R/uaiaewlvEL4ABl7Z539Whqm3d/wKwIeD60FgJNDwU+YBcw3K98FWRPTO6aFkb6MPBSV0jB6DkEc4RBPSdacybRmqvyjgUffjUlLIlKy9Mtb1BQk2YxkoLQEVthIzELMAkGBSsOAwIaBQAwgdQGCSqGSIb3DQEHATAUBggqhkiG9w0DBwQIDosiT6Tlwv6AgbBAKor1Vcw4E9rsqRbApqy795Rax3JBBn6kP1doET6qRJc4h4LxVygzLRpUw+r4Yd/haMEoZcOrleqkOKSwc8bZqFIciHtS12cTFbKtipy4xczqLgkSrOyoeqTKHr42/ryC5QsXsV6a/1+zoZ9jGelz7BKETZ/lDJI8Y2ilMH6xT+zH+8TH6QsviB7AXz3rdQP7fhPzaBbEZRNcTfdZdIQ4BANjWyP9Yl4swEjynRwTaaCCA4cwggODMIIC7KADAgECAgEAMA0GCSqGSIb3DQEBBQUAMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbTAeFw0wNDAyMTMxMDEzMTVaFw0zNTAyMTMxMDEzMTVaMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbTCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAwUdO3fxEzEtcnI7ZKZL412XvZPugoni7i7D7prCe0AtaHTc97CYgm7NsAtJyxNLixmhLV8pyIEaiHXWAh8fPKW+R017+EmXrr9EaquPmsVvTywAAE1PMNOKqo2kl4Gxiz9zZqIajOm1fZGWcGS0f5JQ2kBqNbvbg2/Za+GJ/qwUCAwEAAaOB7jCB6zAdBgNVHQ4EFgQUlp98u8ZvF71ZP1LXChvsENZklGswgbsGA1UdIwSBszCBsIAUlp98u8ZvF71ZP1LXChvsENZklGuhgZSkgZEwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tggEAMAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEFBQADgYEAgV86VpqAWuXvX6Oro4qJ1tYVIT5DgWpE692Ag422H7yRIr/9j/iKG4Thia/Oflx4TdL+IFJBAyPK9v6zZNZtBgPBynXb048hsP16l2vi0k5Q2JKiPDsEfBhGI+HnxLXEaUWAcVfCsQFvd2A1sxRr67ip5y2wwBelUecP3AjJ+YcxggGaMIIBlgIBATCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTExMDYyOTA1MDczMlowIwYJKoZIhvcNAQkEMRYEFF8Br6L6XUMQHIKQpFN9KNilEtSXMA0GCSqGSIb3DQEBAQUABIGAWjzqbXwBNWtwiuE09LTz/EoPrfmLwGd+oY2B0QTVkGy3TdrGanwAbHravBxrkNORQnB+6g5C+By7GdCvWmdpTTYeztc2IG4RvxAADvf10BmyeI8MgEEGPMB4zOUFERdohA3xixiuoi+ImxJnRX0DBsGRkNdYZ/W98DJ1CoASOAQ=-----END PKCS7-----
				"/>
				<a class="black" href="#" onclick="parentNode.submit(); return false;"><strong>Donate via Paypal:</strong></a><input type="image" src="<?php bloginfo('template_directory'); echo "/images/paypallogo.png";?>" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!"/>
				<span class="paypalsubtext">Click Above to Donate! </span>
				<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1"/>
			</form>
			<div class="bitcoincontainer"><strong><a href="/donate" class="black" title="See the donate page for our bitcoin address">Donate via Bitcoin: <span class="sprite bitcoin"></span></a></strong>  <br /> <span class="bitcoinrate">Current Rate from MtGox: </span><br /> 1Bitcoin : <span id="bitcoinval">looking it up...</span> <br /></div>
									
				<script type="text/javascript">
					if( ! jQuery('#donatorCanvas').tagcanvas({
					 textColour : '#333',
					 textHeight : 20,
					 outlineColour : '#005580',
					 outlineMethod : 'outline',
					 outlineThickness : 1,
					 weight: true,
					 weightFrom: 'data-weight',
					 minBrightness : .3,
					 reverse : true,
					 zoom: 1,
					 maxSpeed : 0.03,
					 depth : 0.75,
					 radiusX: 0.9,
					 radiusy: 0.9,
					 initial: [0.002,-0.001]
					})) {
					 // TagCanvas failed to load
					 jQuery('#myCanvasContainer').hide();
					}
					
					jQuery.getJSON("<?php bloginfo('template_directory');?>/mtgox.php", function(data) {
						//console.log(data);
						jQuery("#bitcoinval").html(data);
						});
					
				</script>
		<?php
		echo $after_widget;
	}

	// This is the function that outputs the form to let the users edit
	// the widget's title. It's an optional feature that users cry for.
	function widget_donors_control() {

		// Get our options and see if we're handling a form submission.
		$options = get_option('widget_donors');
		if ( !is_array($options) )
			$options = array('title' => 'Big Thanks to our Donors!', 'donors'=> array( "0" => array('name' => "Neal", "weight" => "20px", "url" => "")));
		if ( $_POST['donors-submit'] ) {

			// Remember to sanitize and format use input appropriately.
			
			$options['title'] = strip_tags(stripslashes($_POST['donors-title']));
			$donorNumber = 0;
			while(!empty($_POST['donors-name-'.$donorNumber])){
				$options['donors'][$donorNumber]['name'] = strip_tags(stripslashes($_POST['donors-name-'.$donorNumber]));
				$options['donors'][$donorNumber]['weight'] = strip_tags(stripslashes($_POST['donors-weight-'.$donorNumber]));
				$options['donors'][$donorNumber]['url'] = strip_tags(stripslashes($_POST['donors-url-'.$donorNumber]));
				$donorNumber++;
			}
			update_option('widget_donors', $options);
		}

		// Be sure you format your options to be valid HTML attributes.
		
		$title = htmlspecialchars($options['title'], ENT_QUOTES);
		$donors = $options['donors'];
		
		// Here is our little form segment. Notice that we don't need a
		// complete form. This will be embedded into the existing form.
		echo '<p style="text-align:left;"><label for="donors-title">' . __('Title:') . ' <input style="width: 200px;" id="donors-title" name="donors-title" type="text" value="'.$title.'" /></label></p>';
		echo '<br />';
		echo '<span style="text-align:left; margin-right: 15px; margin-left: 5px;">Name:</span><span style="text-align:left; margin-right: 10px;">Weight:</span><span style="text-align:left;">Url:</span>';
		echo '<br />';
		$donorNumber = 0;
		foreach ($donors as $donor): 
		echo '<input style="width: 50px;" id="donors-name-'.$donorNumber.'" name="donors-name-'.$donorNumber.'" type="text" value="'.$donor['name'].'" />';
		echo '<input style="width: 50px;" id="donors-weight-'.$donorNumber.'" name="donors-weight-'.$donorNumber.'" type="text" value="'.$donor['weight'].'" />';
		echo '<input style="width: 100px;" id="donors-url-'.$donorNumber.'" name="donors-url-'.$donorNumber.'" type="text" value="'.$donor['url'].'" />';
		echo '<br />';
		$donorNumber++;
		endforeach;
		echo '<a href="javascript:;" id="add_donor" title="Add another donor"><i class="add_donor" style="display:inline-block;width:14px;height:14px;line-height:14px;vertical-align:text-top;">+</i> </a>';
		echo '<input type="hidden" id="donors-submit" name="donors-submit" value="1" />';
		?>
		<script type="text/javascript">
		var DonorNum;
		DonorNum = <?php echo $donorNumber; ?>;
		jQuery(".add_donor").click(function() {
		
		  jQuery(this).before('<input style="width: 50px;" id="donors-name-'+ DonorNum +'" name="donors-name-'+ DonorNum +'" type="text" value="new" /><input style="width: 50px;" id="donors-weight-'+ DonorNum +'" name="donors-weight-'+ DonorNum +'" type="text" value="20" /><input style="width: 100px;" id="donors-url-'+ DonorNum +'" name="donors-url-'+ DonorNum +'" type="text" value="/donations" /><br/>');
		DonorNum++;
		});
		jQuery("#add_donor").click(function(event){
		  event.stopPropagation();
		});
		</script>
		<?php
	}
	
	// This registers our widget so it appears with the other available
	// widgets and can be dragged and dropped into any active sidebars.
	register_sidebar_widget(array('Donors', 'widgets'), 'widget_donors');

	// This registers our optional widget control form. Because of this
	// our widget will have a button that reveals a 300x100 pixel form.
	register_widget_control(array('Donors', 'widgets'), 'widget_donors_control', 250, 100);
}

// Run our code later in case this loads prior to any required plugins.
add_action('widgets_init', 'widget_donors_init');

?>